# 论文展示主页（EffiEval 风格）— ARM 示例

这个文件夹已经包含一个**可直接部署的静态论文主页**，效果参考你给的 EffiEval 页面：大标题 + 作者 + 三个按钮 + Key Takeaways + 分节内容 + BibTeX。

目录结构：

```
arm-paper-homepage/
├── index.html
├── paper.pdf
└── assets/
    ├── style.css
    ├── script.js
    └── img/
        ├── fig1.png
        ├── fig2.png
        ├── table1.png
        └── table2.png
```

---

## 1) 本地预览（推荐）

> 直接双击打开 `index.html` 也可能能看，但很多浏览器对本地文件加载/跳转限制较多；最稳妥是起一个本地静态服务器。

在 `arm-paper-homepage/` 目录下运行：

```bash
python -m http.server 8000
```

然后浏览器打开：

```
http://localhost:8000
```

---

## 2) 部署到 GitHub Pages（最常用）

1. 新建一个 GitHub 仓库，比如 `your-paper-homepage`
2. 把本目录下所有文件（`index.html / assets / paper.pdf` 等）上传到仓库根目录
3. GitHub 仓库 Settings → Pages → Build and deployment：
   - Source: Deploy from a branch
   - Branch: `main` / root
4. 等待 GitHub Pages 发布即可访问

---

## 3) 你需要改哪些内容？

打开 `index.html`，重点改这几处：

- 标题：`<h1>...</h1>` 和 `<title>...</title>`
- 作者列表：`<p class="authors">...</p>`
- 单位：`<p class="affiliations">...</p>`
- 三个按钮：
  - PDF：默认链接 `paper.pdf`（你可以替换为 arXiv 链接）
  - GitHub：我目前是占位，会弹窗提示你改成自己的仓库链接
  - Contact：`mailto:xxx@xxx.com`

- Key Takeaways：在 `Key Takeaways` 的 `<li>...</li>` 里改成你的三条贡献/卖点
- 下面正文各节：直接编辑 HTML 段落即可
- BibTeX：替换 `@misc{...}` 块

---

## 4) 图片怎么换？

所有图片放在：

```
assets/img/
```

`index.html` 里对应引用，例如：

```html
<img src="assets/img/fig2.png" />
```

你只要把图片文件名保持一致，替换文件即可。

---

## 5) MathJax（公式渲染）

网页里默认启用了 MathJax（通过 CDN）来渲染 LaTeX 公式。
如果你不需要公式，可以删掉 `index.html` 头部这两段：

```html
<script>
  window.MathJax = ...
</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
```

如果你在某些网络环境下 CDN 不稳定，可以把 MathJax 下载到本地，然后把 `src="..."` 改成相对路径。

---

如需把你的其它论文也做成同样的风格：复制整个目录 → 换 `paper.pdf` → 换文字/图片即可。
